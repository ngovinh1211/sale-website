<?php

// file App.php đọc url và phân tích đường dẫn
require_once('./mvc/core/App.php');

// gọi model, view và một số thư viện
require_once('./mvc/core/Controller.php');

// kết nối đến database
require_once('./mvc/core/DB.php');
?>