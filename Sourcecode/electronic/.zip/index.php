<?php
session_start();
require_once('./mvc/brigde.php');
$myApp = new App();
?>